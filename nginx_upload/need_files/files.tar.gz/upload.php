<html>
 <head>
  <title>upload result</title>
 </head>
 <body>
 <?php echo '<p>success</p>'; ?>
 </body>
</html>
